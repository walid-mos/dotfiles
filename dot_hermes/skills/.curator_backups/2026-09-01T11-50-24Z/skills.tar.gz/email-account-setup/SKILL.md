---
name: email-account-setup
description: "Use when wiring mail accounts into himalaya v2 for terminal."
version: 1.0.0
license: MIT
---

# Email Account Setup (himalaya v2 + Ortie)

Class-level playbook for connecting a user's mailboxes so the agent can read/search/send from the terminal. Validated end-to-end on 2026-08-24 with 4 accounts (1 Gmail, 1 Zoho, 2 personal Outlook).

## himalaya v2 config syntax (BREAKING vs v1)

v2.1.0 does NOT use the old nested-table syntax (`backend.type = "imap"`,
`backend.auth.cmd = ...`). That parses but silently yields "No backend matching
`auto` is configured". The working form is flat per-protocol keys:

```toml
[accounts.gmail]
email = "user@gmail.com"
display-name = "Name"
default = true

imap.server = "imaps://imap.gmail.com:993"
imap.sasl.plain.username = "user@gmail.com"
imap.sasl.plain.password.command = ["security", "find-generic-password", "-a", "user@gmail.com", "-s", "<service>", "-w"]

smtp.server = "smtps://smtp.gmail.com:465"
smtp.sasl.plain.username = "user@gmail.com"
smtp.sasl.plain.password.command = [ ...same... ]

mailbox.alias.inbox = "INBOX"
```

Pitfalls:
- **Every** account needs `mailbox.alias.inbox = "INBOX"` or shared commands
  (`envelope list`) fail with "Mailbox is required".
- Verify with `himalaya account check --account X --backend imap`.
- Wizard needs a real TTY → run inside tmux (`tmux new-session -d -s s '...'`
  then `tmux send-keys`); plain background pipes get "Configuring needs a terminal".

## Secrets

Store app passwords in macOS Keychain, never in config:
`security add-generic-password -a <email> -s <service> -w '<password>'`

## Provider specifics

| Provider | IMAP | Auth |
|---|---|---|
| Gmail | imaps://imap.gmail.com:993 | App password (requires 2FA; app-passwords page shows "not available for your account" until 2FA is on) |
| Zoho EU | imaps://imap.zoho.eu:993 | App password from **accounts.zoho.com → Security → App Passwords** (NOT inside Zoho Mail settings) |
| Outlook personal | imaps://outlook.office365.com:993 | **OAuth2 only** — see references/microsoft-oauth2-personal.md |

## Personal Outlook (@outlook.fr / @hotmail) — read the reference first

Basic auth and app passwords are dead on personal Microsoft accounts. The only
working path is OAuth2 authorization-code + PKCE using Thunderbird's public
client id, brokered by **Ortie**, wired into himalaya as an XOAUTH2 token
command. Full validated recipe, pitfalls (expiring codes, state/pkce matching,
lost tokens from bad storage.write), and the token-wrapper script are in
[references/microsoft-oauth2-personal.md](references/microsoft-oauth2-personal.md).
