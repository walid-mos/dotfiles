#!/usr/bin/env python3
"""Print a fresh Microsoft access token for an ortie-managed account.
Usage: ms-token.py <account>   (e.g. outlook1)
Reads ~/.local/share/ortie/<account>.json; refreshes via ortie when the token
is within 2 minutes of expiry. Prints only the access token on stdout, for use
as himalaya's imap.sasl.xoauth2.token.command / smtp.sasl.xoauth2.token.command."""
import json, os, subprocess, sys, time

account = sys.argv[1]
path = os.path.expanduser(f"~/.local/share/ortie/{account}.json")
d = json.load(open(path))

expires_at = int(d.get("issued_at", 0)) + int(d.get("expires_in", 3600))
if time.time() > expires_at - 120:
    subprocess.run(["ortie", "token", "refresh", "--account", account],
                   capture_output=True)
    d = json.load(open(path))

print(d["access_token"])
