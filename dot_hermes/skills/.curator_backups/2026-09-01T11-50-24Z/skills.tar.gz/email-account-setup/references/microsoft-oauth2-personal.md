# Microsoft / Outlook personal accounts: OAuth2 via Ortie

Basic auth AND app passwords are dead on personal @outlook/@hotmail accounts
(Microsoft disabled them ~Sept 2024). IMAP/SMTP only works via OAuth2 XOAUTH2.
Entra ID app registration is NOT possible with only a personal account
(Entra rejects personal Microsoft accounts at login).

## Working recipe (validated 2026-08)

1. Install **Ortie** (Pimalaya token broker, same author as himalaya):
   download `ortie.aarch64-darwin.tgz` from https://github.com/pimalaya/ortie/releases
   and put the binary on PATH.

2. Config `~/.config/ortie/config.toml` — use the **public Thunderbird client id**
   (pre-authorized by Microsoft for personal accounts). Set REAL storage BEFORE
   the first grant:

```toml
[accounts.outlook1]
client-id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"
endpoints.authorization = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
endpoints.token = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
endpoints.redirection = "https://localhost"
scopes = ["https://outlook.office.com/IMAP.AccessAsUser.All", "https://outlook.office.com/SMTP.Send", "offline_access"]
pkce = true
auto-refresh = true
storage.read.command = ["cat", "<home>/.local/share/ortie/outlook1.json"]
storage.write.command = "cat > <home>/.local/share/ortie/outlook1.json && chmod 600 <home>/.local/share/ortie/outlook1.json"
```

3. Grant flow (needs user interaction):
   - Run `ortie auth get --account X` inside **tmux** (needs a TTY; plain pipes fail).
     It prints state + pkce verifier + an authorize URL.
   - `open` the URL; user consents; Safari lands on error page
     `https://localhost/?code=...` — EXPECTED, not a failure.
   - User pastes that full URL (copy from address bar, ⌘L⌘C — retyping corrupts it).
   - Resume: `ortie auth resume --account X --state='<state>' --pkce='<verifier>' '<url>'`
   - Token JSON lands in storage: keys access_token, expires_in, refresh_token,
     issued_at. Refresh with `ortie token refresh --account X`.

## Pitfalls

- Auth codes expire in ~2 min and are single-use; state+pkce must match the exact
  auth get that produced them. If the user takes too long, regenerate.
- If storage.write is unset/wrong (e.g. `true`), issued tokens are LOST and the
  browser grant must be redone. Configure storage first.
- Device-code flow does NOT work here: Thunderbird client id → AADSTS9002332 on
  `/consumers`; first-party MS client ids refuse user consent ("users are not
  permitted to consent to first party applications"). Only authorization-code +
  PKCE loopback works for personal accounts.

## Wiring into himalaya v2

himalaya v2 delegates OAuth to external brokers. Point xoauth2 at a wrapper
that reads the ortie JSON and refreshes when near expiry:

```toml
[accounts.outlook1]
imap.server = "imaps://outlook.office365.com:993"
imap.sasl.xoauth2.username = "user@outlook.fr"
imap.sasl.xoauth2.token.command = ["python3", "<path>/ms-token.py", "outlook1"]
smtp.server = "smtp.office365.com:587"
smtp.starttls = true
smtp.sasl.xoauth2.username = "user@outlook.fr"
smtp.sasl.xoauth2.token.command = ["python3", "<path>/ms-token.py", "outlook1"]
mailbox.alias.inbox = "INBOX"
```

Wrapper logic (~20 lines of Python): load JSON; if now > issued_at + expires_in
− 120s, run `ortie token refresh --account X`; print access_token on stdout.
Working copy lives at ~/.config/himalaya/ms-token.py on Walid's machine.
