---
name: x-bookmark-curation
description: Use when curating X bookmarks. Sync and verify.
version: 1.0.0
author: Hermes Curator
license: MIT
metadata:
  hermes:
    tags: [x, bookmarks, obsidian, automation]
    related_skills: []
---

## When to Use

Use for recurring or user-requested X/Twitter bookmark collection, deterministic folder classification, X bookmark-folder maintenance, and Obsidian Brain synchronization. It covers both scheduled, no-prompt runs and explicit requests to add or refine a bookmark category. For account analytics audits or audience-growth work, use `x-audience-growth` instead.

**Pitfall (verified 2026-09): never do interactive multi-step browsing in the DEFAULT `browser_exec` session.** It is shared with scheduled cron runs — mid-session, a cron job (freelance-presence) navigated the shared tab away and destroyed the page state. Always pass an isolated named session (e.g. `browser_exec(..., session='x-growth')`) and reuse that name for all related calls. The bookmarks cron flow is the exception: it runs in its own scheduled context.

# X/Twitter Bookmark Curation

Use this class-level skill for recurring workflows that collect an authenticated user's new X/Twitter bookmarks, classify them into X bookmark folders, and mirror them into an Obsidian vault. The workflow is designed for scheduled, no-prompt runs and preserves the user's existing state.

Session-specific GraphQL details and observed response shapes live in [`references/x-graphql-bookmark-folders.md`](references/x-graphql-bookmark-folders.md).

## Safety and scope

1. Operate only on the authenticated user's existing browser session. Never ask for, print, store, or infer a password. Do not expose bearer or CSRF values in reports or files.
2. The only permitted X write is adding an already-bookmarked tweet to a bookmark folder, plus creating a requested missing folder. Do not like, repost, post, delete, unbookmark, or move content unless the user explicitly asks.
3. Keep vault writes confined to the configured Twitter Bookmarks destination: `1. Flux/Twitter Bookmarks/`.
4. Preserve user-supplied identifiers literally. If the user requests a folder named `Carrer`, keep that exact spelling in X, the folder map, classifier, vault tags, and scheduled prompt; do not silently normalize it to `Career`.
5. For scheduled runs, if there is genuinely no new tweet, return exactly `[SILENT]` and do not touch the vault or state.

## 1. Discover state before browsing

Read, without rewriting, these files:

- `~/.hermes/bookmarks-agent/state/state.json` — `known_ids`, `last_run`.
- `~/.hermes/bookmarks-agent/state/x_folders.json` — folder name to collection ID.
- `~/.hermes/bookmarks-agent/data/bookmarks_full.json` — canonical deduplicated archive.
- `~/.hermes/bookmarks-agent/build_vault.py` — the authoritative vault classifier and destination.

Treat `build_vault.py` as the source of truth for classification. If a new user-requested category is added, update the classifier and the scheduled prompt together so X folder placement and vault tags stay aligned.

**Pitfall (Brain v2 migration, 2026-08):** when the Obsidian vault is restructured, `build_vault.py`'s `DEST` silently keeps writing to the OLD path and recreates the stale tree at the next cron run. Before or during any vault reorganization, `grep -n "DEST\|VAULT" ~/.hermes/bookmarks-agent/build_vault.py`, update `DEST` to the new path, update rule 3 of this skill to match, and verify with a real read. General rule: check which automation WRITES into a vault folder before moving that folder — the mover must update every writer in the same pass.

## 2. Collect only new bookmarks

1. Use `browser_exec` on `https://x.com/i/history` in the existing logged-in Chrome session.
2. Extract tweet records with this DOM logic, keeping `id`, `author`, canonical `url`, ISO `date`, and visible `text`:

```js
(() => {
  const out = [];
  for (const a of document.querySelectorAll('article[data-testid="tweet"]')) {
    const timeEl = a.querySelector('time');
    let permalink = null;
    for (const l of a.querySelectorAll('a[href*="/status/"]')) permalink = l.href;
    if (!permalink) continue;
    const txt = a.querySelector('[data-testid="tweetText"]');
    out.push({
      id: permalink.split('/status/')[1].split('/')[0],
      author: (permalink.split('x.com/')[1] || '').split('/status')[0].split('?')[0],
      url: permalink.replace(/\/analytics$/, ''),
      date: timeEl ? timeEl.getAttribute('datetime') : null,
      text: txt ? txt.innerText : ''
    });
  }
  return out;
})()
```

3. After each extraction, scroll with `window.scrollTo(0, document.body.scrollHeight)` and wait about 2 seconds. Stop as soon as a loaded batch contains a `known_ids` entry; cap the loop at 100 scrolls.
4. Deduplicate loaded records by tweet ID before filtering. A tweet is new iff its ID is absent from `known_ids`; do not use date alone.
5. Save the collected batch or an equivalent durable intermediate before long processing if a run may exceed a tool timeout. Verify the intermediate count against the number of new IDs.

## 3. Classify with deterministic first-match rules

Classification is case-insensitive and is first-match-wins. Keep the regexes in the cron prompt and `build_vault.py` synchronized. For a career folder requested by the user, put its rule before broader technical rules, for example:

- `Carrer`: `\b(hiring|hire|recruit|recruiting|job|jobs|career|careers|candidate|employment|work with us)\b`
- AI & Agents: `\bagent(s)?\b|claude|codex|cursor|mcp|llm|gpt|grok|gemini|openai|anthropic|nous|opus|sonnet|qwen|mlx|inference|prompt`
- Dev: `code|typescript|python|rust|golang|api|git|sql|react|node|css|html|deploy|docker|kubernetes|regex`
- Design: `design|ui\b|ux\b|figma|typographie|font|couleur|landing|three\.js|animation|css art`
- Productivité: `productivité|workflow|notion|obsidian|calendar|routine|schedule|habitude|focus`
- Business: `saas|startup|pricing|revenue|mrr|client|freelance|mission|prospection|vente|invoice`
- À lire: no match

Avoid overly broad career tokens such as standalone `offer`: an employee tender offer is not automatically a job offer. If the user intentionally wants company/equity announcements in that folder, make that an explicit rule and use it consistently in both X and vault classification.

## 4. Obtain authenticated headers without credentials

1. Install an in-page XHR hook through `js()` that records only requests whose URL contains `/graphql/`, capturing `open`, `setRequestHeader`, and `send`.
2. Trigger authenticated GraphQL traffic by clicking the `Likes` tab (`a[href="/i/history/likes"]`) and returning to the bookmarks page. Read the latest captured `authorization` and `x-csrf-token` values in memory only.
3. Never print the header values. If navigation destroys the hook, reinstall it and perform the Likes round-trip again in the same `browser_exec` call before making writes.
4. Scheduled runs must go through the dedicated agent Chrome instance (see section 7). If the macOS "Allow remote debugging?" consent sheet appears, you are attached to the user's LIVE Chrome — that path blocks unattended runs; switch to the agent Chrome (`browser.cdp_url`) instead. Approving the dialog via computer-use is acceptable only in an attended foreground session at the user's explicit request. Do not use a password or change unrelated Chrome settings.

## 5. Create missing folders and add tweets

Read `x_folders.json` first. If a requested folder name is missing, create it through the authenticated page context:

- `POST /i/api/graphql/6Xxqpq8TM_CREYiuof_h5w/createBookmarkFolder`
- body: `{variables: JSON.stringify({name}), queryId: '6Xxqpq8TM_CREYiuof_h5w'}`

Parse the returned collection ID from the response, verify the response includes the requested name and a new ID, then update `x_folders.json` atomically. Never guess an ID.

For each new tweet, add it to the classified folder:

- `POST /i/api/graphql/4KHZvvNbHNf07bsgnL9gWA/bookmarkTweetToFolder`
- headers: `authorization`, `x-csrf-token`, `content-type: application/json`
- `credentials: 'include'`
- body: `{variables: JSON.stringify({tweet_id, bookmark_collection_id}), queryId: '4KHZvvNbHNf07bsgnL9gWA'}`

Use 350–800 ms random delay between writes. Keep each `js()` evaluation to at most five write calls and run the outer loop in Python. Record each response status and body result. Treat only a successful response such as HTTP 200 plus `bookmark_collection_tweet_put: "Done"` as a completed assignment.

Do not retry a write blindly after an uncertain timeout. First inspect the target or response state to avoid duplicate actions; X folder adds are intended to be idempotent at the workflow level but the verification still matters.

## 6. Merge, build, and update state

1. Merge the new records into `bookmarks_full.json` by ID. Preserve existing records and ensure the final list has no duplicate IDs.
2. Run:

```sh
python3 ~/.hermes/bookmarks-agent/build_vault.py
```

3. Update `state.json` only after the X writes and vault build succeed: append the new IDs uniquely, set `last_run` to the actual local date, and keep any existing state fields.
4. Verify all acceptance criteria with real reads: final archive count, unique-ID count, state/archive ID-set equality, new note presence, spine presence, and folder-map presence.
5. For a newly created folder, read back its exact X target when practical (folder page or authenticated collection response). A creation response alone is useful evidence but do not claim broader contents without a readback.

## 7. Scheduled-run reliability (cron)

- The cron browser toolset is named `browser` — NOT `browser-use`. A per-job `enabled_toolsets` containing an unknown name acts as a strict allowlist and silently drops the browser tools; the run then fails with "browser_exec n'est pas disponible". Correct pin: `enabled_toolsets: ["browser", "file", "terminal"]`.
- Scheduled runs must use the dedicated agent Chrome instance (`browser.cdp_url: http://127.0.0.1:9223` in config.yaml): a launchd LaunchAgent `com.walid.chrome-agent` keeps a Chrome copy (profile snapshot with logins at `~/Library/Application Support/Google/Chrome-Agent`) running with `--remote-debugging-port=9223`. Never attach to the user's live Chrome from cron — macOS shows the "Allow remote debugging?" consent sheet, which blocks unattended runs.
- If a run reports the browser tool missing, first check: (1) `hermes config get browser.cdp_url`, (2) `curl -s http://127.0.0.1:9223/json/version`, (3) `launchctl list | grep chrome-agent`, (4) the job's `enabled_toolsets` contains `browser`.
- Health probe pattern: create a one-shot cron job that just calls `browser_exec` with `new_tab('https://example.com')` + `page_info()` to verify the cron environment before touching X state.
- Repair and re-sync recipes (session lost, snapshot stale, LaunchAgent rebuild): [`references/chrome-agent-maintenance.md`](references/chrome-agent-maintenance.md).

## 8. Scheduled report format

When there are new bookmarks, report only:

- number of new bookmarks;
- X-folder distribution;
- the Obsidian spine link, normally `[[Twitter Bookmarks]]` and/or its vault path.

Mention a newly created folder or classifier change briefly when relevant. Do not include credentials, raw API payloads, or unnecessary tweet text. If any write or verification is incomplete, report the blocker plainly instead of claiming success.
