# Microsoft OAuth2 for personal Outlook.com accounts — validated walkthrough

Session-validated on 2026-08-24 for @outlook.fr personal accounts (Basic auth disabled by
Microsoft since Sept 2024; app passwords rejected with "NO Basic authentication is disabled").

## Dead ends (do not retry)

1. **App passwords / basic auth IMAP** → `NO Basic authentication is disabled.` Not fixable.
2. **Entra ID app registration** → personal accounts cannot even sign in to Entra portal
   ("user does not exist in tenant 'Microsoft Services'").
3. **Device-code flow, Thunderbird client id** (`08162f7c-0fd2-4200-a84a-f25a4db0b584`) via
   `/consumers` → `AADSTS9002332: configured for Azure Active Directory users only`. Via
   `/common` it starts but the token exchange fails for consumer accounts.
4. **Device-code flow, first-party MS clients** (Office `d3590ed6-…`, Azure CLI `1950a258-…`)
   → consent page errors: "the user does not have consent, and users are not permitted to
   consent to first party applications".
5. **himalaya v2 built-in OAuth** → v2 removed it ("Himalaya runs no OAuth 2.0 grant itself");
   the wizard only configures external brokers (ortie/pizauth/oama). Source: himalaya issues
   #618/#582.

## Working path: ortie + Thunderbird public client

The Thunderbird **IMAP/SMTP** client id `9e5f94bc-e8a4-4e73-b8be-63364c29d753` is pre-authorized
by Microsoft for consumer accounts with Outlook IMAP scopes. Use it with the standard
authorization-code + PKCE flow through ortie.

Install ortie from https://github.com/pimalaya/ortie/releases (aarch64-darwin tgz).

### ortie config (~/.config/ortie/config.toml)

```toml
[accounts.outlook1]
client-id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"
endpoints.authorization = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
endpoints.token = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
endpoints.redirection = "https://localhost"
scopes = ["https://outlook.office.com/IMAP.AccessAsUser.All", "https://outlook.office.com/SMTP.Send", "offline_access"]
pkce = true
auto-refresh = true
storage.read.command = ["cat", "/Users/<u>/.local/share/ortie/outlook1.json"]
storage.write.command = "cat > /Users/<u>/.local/share/ortie/outlook1.json && chmod 600 /Users/<u>/.local/share/ortie/outlook1.json"
```

⚠️ The storage.write command receives the token JSON on stdin. A placeholder like `true`
discards it silently — auth reports success but nothing is stored.

### Grant flow (one interactive round per account)

1. Run `ortie auth get --account X` inside tmux (needs a TTY); it prints state, pkce verifier,
   and the authorize URL.
2. `open <url>`; user signs into the personal MS account in the browser and consents.
3. Browser redirects to `https://localhost/?code=...&state=...` which fails to load (nothing
   listens) — that error page IS the success signal. User must copy the full URL quickly:
   authorization codes expire within ~2 minutes.
4. Resume exactly as ortie printed it:
   `ortie auth resume --account X --state='<state>' --pkce='<verifier>' '<redirected URI>'`.
   - state is case-sensitive; a screenshot/OCR re-transcription will mismatch → InvalidGrant
     "state" or PKCE errors. Always get the URL pasted verbatim.
   - Each new `auth get` invalidates prior grants' verifiers; keep state+pkce pairs together.

Stored JSON shape: `{access_token, token_type, expires_in, refresh_token, scope, issued_at}`.

### Feeding himalaya

himalaya xoauth2 needs a command that prints just the access token. Wrapper script
(scripts/ms-token.py in this skill): reads the JSON, refreshes via `ortie token refresh` when
within 120s of expiry, prints `access_token`.

```toml
imap.sasl.xoauth2.username = "user@outlook.fr"
imap.sasl.xoauth2.token.command = ["python3", "<path>/ms-token.py", "<account>"]
smtp.server = "smtp.office365.com:587"
smtp.starttls = true
smtp.sasl.xoauth2.username = "user@outlook.fr"
smtp.sasl.xoauth2.token.command = ["python3", "<path>/ms-token.py", "<account>"]
```

Verified end-to-end: raw IMAP `AUTHENTICATE XOAUTH2` returns `OK AUTHENTICATE completed` and
`himalaya envelope list --account X` lists the inbox.

Note: himalaya's own wizard (`himalaya configure`) works interactively in tmux for account
discovery but its keyring-token strategy failed here; the file-storage + wrapper approach above
is the one that worked.
