---
name: email-accounts-setup
description: "Wire a mail account into himalaya CLI. Use when adding mail."
version: 1.0.0
platforms: [macos]
metadata:
  hermes:
    tags: [Email, IMAP, SMTP, himalaya, OAuth2]
---

# Email accounts setup (himalaya CLI)

Himalaya manages multiple IMAP/SMTP accounts from one config (`~/.config/himalaya/config.toml`).
**v2.x changed the config format completely** — the old `[accounts.X] backend.type = "imap"` flat
syntax from pre-v2 docs silently yields "No backend matching `auto`". Working v2 shape:

```toml
[accounts.NAME]
email = "user@example.com"
display-name = "Name"

imap.server = "imaps://host:993"
imap.sasl.plain.username = "user@example.com"
imap.sasl.plain.password.command = ["security", "find-generic-password", "-a", "USER", "-s", "SERVICE", "-w"]

smtp.server = "smtps://host:465"
smtp.sasl.plain.username = "user@example.com"
smtp.sasl.plain.password.command = ["security", ...]

mailbox.alias.inbox = "INBOX"
```

Verify with `himalaya account check --account NAME --backend imap`, list with
`himalaya envelope list --account NAME`. Secrets go in macOS Keychain
(`security add-generic-password -a USER -s SERVICE -w 'PASS'`), never in the config file.

## Provider notes

| Provider | IMAP | Auth |
|---|---|---|
| Gmail | imaps://imap.gmail.com | App password (requires 2FA on) — https://myaccount.google.com/apppasswords |
| Zoho EU | imaps://imap.zoho.eu | App password at accounts.zoho.com → Security → App Passwords (NOT in Zoho Mail settings) |
| Outlook personal | imaps://outlook.office365.com | **Basic auth disabled since 2024 — app passwords do NOT work.** OAuth2 via ortie, see references/microsoft-oauth.md |

## Pitfalls

- Gmail app passwords page shows "not available for your account" until 2-Step Verification is enabled.
- Zoho app passwords live in the *Zoho account* portal (accounts.zoho.com), not Zoho Mail settings.
- Microsoft Entra ID portal rejects personal @outlook.fr/@hotmail accounts ("user does not exist in
  tenant") — you cannot register your own app with a personal account.
- Device-code flow with Thunderbird client id fails for consumers ("configured for Azure AD users
  only"); first-party MS clients fail consent ("users are not permitted to consent"). Only the
  authorization-code flow with the Thunderbird public client works for personal accounts.

## Microsoft OAuth2 for personal Outlook accounts (validated recipe)

Tooling: **ortie** (Pimalaya OAuth token broker, install from GitHub releases) +
`~/.config/ortie/config.toml` with Thunderbird public client
`client-id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"`, endpoints
`login.microsoftonline.com/common/oauth2/v2.0/{authorize,token}`,
`endpoints.redirection = "https://localhost"`,
scopes `IMAP.AccessAsUser.All SMTP.Send offline_access`, `pkce = true`.

Storage must be explicit (default keyring path was unreliable):
```toml
storage.read.command = ["cat", "~/.local/share/ortie/<acct>.json"]
storage.write.command = "cat > ~/.local/share/ortie/<acct>.json && chmod 600 <file>"
```
⚠️ A placeholder write command like `true` silently discards the token — auth succeeds but nothing is saved; redo the flow after fixing storage.

Flow (needs user interaction once per account):
1. Run `ortie auth get --account X` in tmux — it prints state + pkce verifier + authorize URL.
2. `open` the URL; user signs in with the personal MS account and consents.
3. Browser lands on an error page (`https://localhost/?code=...`) — expected; ask user to copy
   the URL fast (code expires ~2 min).
4. `ortie auth resume --account X --state='<state>' --pkce='<verifier>' '<redirected URI>'`.
   State/pkce MUST match that exact grant; OCR-transcribed URLs fail on case-sensitive state.

Then feed himalaya via XOAUTH2 with a wrapper script that reads the stored JSON and prints
`access_token` (refresh if expired): see `scripts/ms-token.py`. Himalaya config:
```toml
imap.sasl.xoauth2.username = "user@outlook.fr"
imap.sasl.xoauth2.token.command = ["python3", ".../ms-token.py", "<account>"]
```

## See also

- `references/microsoft-oauth.md` — full walkthrough incl. dead ends (device code, first-party clients)
- `scripts/ms-token.py` — token provider script for himalaya xoauth2.command
