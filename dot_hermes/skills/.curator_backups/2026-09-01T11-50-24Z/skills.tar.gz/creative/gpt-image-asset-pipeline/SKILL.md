---
name: gpt-image-asset-pipeline
description: "Use for local upscale of GPT Image outputs into assets."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [gpt-image, upscale, backgrounds, assets, comfyui]
    related_skills: [comfyui]
---

# GPT Image Asset Pipeline

## When to Use

Use this when Walid asks to upscale, export, or create a high-resolution asset from an image already generated in ChatGPT/GPT Image. GPT Image remains the generation source; ComfyUI local performs the upscale and exact sizing.

## Paths

- Root: `~/Documents/Hermes/Image Pipeline/`
- Script: `~/Documents/Hermes/Image Pipeline/asset_pipeline.py`
- Presets: `~/Documents/Hermes/Image Pipeline/presets.json`
- Input inbox: `~/Pictures/Hermes Assets/inbox/`
- Final files: `~/Pictures/Hermes Assets/outputs/`
- Metadata JSON: `~/Pictures/Hermes Assets/metadata/`
- Local ComfyUI: `~/Documents/Hermes/Image Pipeline/ComfyUI`, port `8188`

## Interaction

1. If an image file was attached to chat, use that local path. Otherwise ask the user to download the ChatGPT image into the inbox or give the exact local path.
2. Confirm the intended preset when not stated. Presets currently available:
   - `wallpaper-4k` 3840×2160
   - `wallpaper-5k` 5120×2880
   - `wallpaper-6k` 6144×3456
   - `portrait-4k` 2160×3840
   - `square-4k` / `texture-4k` 4096×4096
3. Preserve the original generation prompt in `--prompt` when the user provides it. It is archived in JSON sidecar metadata.
4. Run:

```bash
python3 "$HOME/Documents/Hermes Image Pipeline/asset_pipeline.py" \
  --input "/absolute/path/to/source.png" \
  --preset wallpaper-5k \
  --name "short-descriptive-name" \
  --prompt "original generation prompt"
```

5. Verify the final PNG dimensions with `sips -g pixelWidth -g pixelHeight -g format OUTPUT_PATH`. Deliver the resulting file as `MEDIA:/absolute/path` and mention the output dimensions.

## Troubleshooting

- First check server status: `curl -fsS http://127.0.0.1:8188/system_stats`.
- If it is unavailable, start from the ComfyUI root using its isolated Python so Hermes dependencies do not leak in:

```bash
cd "$HOME/Documents/Hermes Image Pipeline/ComfyUI"
env -u PYTHONPATH -u VIRTUAL_ENV .venv/bin/python main.py --port 8188
```

Use a Hermes-managed background process for that command.
- The upscaler is `RealESRGAN_x4plus.pth` at `ComfyUI/models/upscale_models/`. Confirm it is visible by querying `http://127.0.0.1:8188/object_info/UpscaleModelLoader`.
- Do not claim a high-resolution file exists until `sips` confirms its exact pixel dimensions.

## Design boundary

This is intentionally the post-generation pipeline. Do not claim that the active Codex/ChatGPT OAuth can programmatically call OpenAI Images API; it cannot. The user manually creates/downloads the source in ChatGPT, then Hermes completes the local pipeline.
