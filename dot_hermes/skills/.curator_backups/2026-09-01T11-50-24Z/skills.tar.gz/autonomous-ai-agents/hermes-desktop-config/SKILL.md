---
name: hermes-desktop-config
description: "Use when configuring or verifying Hermes desktop settings."
version: 1.0.0
---

# Hermes Desktop — configuration & verification

Class-level know-how for answering "can Hermes do X in the desktop app / where is that setting" and for *verifying* real config state. The bundled `hermes-agent` skill is the hub; this file holds the details that session work actually surfaced.

## Golden rule: verify real state, never trust the UI pane

The desktop **Settings → Plugins** pane lists every bundled plugin with toggles that can render ON even when nothing is loaded. The authoritative state is:

```bash
hermes plugins list          # status column: enabled / disabled / not enabled
grep -A10 "^plugins:" ~/.hermes/config.yaml
```

`plugins.enabled: []` in config.yaml means **zero plugins active**, regardless of what the UI shows. Before telling the user "you use plugin X", check:

1. `hermes plugins list` status
2. config.yaml `plugins.enabled`
3. whether the required API key exists in `~/.hermes/.env` (a plugin without its key is inert even if enabled)

## Two things named "browser use" — do not confuse them

| | Built-in `browser_exec` | Plugin `browser-browser-use` |
|---|---|---|
| What | Browser Use **CLI mode** of the built-in browser tool | Cloud backend at api.browser-use.com |
| Backend | Any CDP target (e.g. `browser.cdp_url: http://127.0.0.1:9223` = local Chrome) | Remote cloud browser |
| Auth | None (CDP) | `BROWSER_USE_API_KEY` or Nous gateway |
| Independent? | Yes — hardcoded in `tools/browser_tool.py`, not gated by the plugin | Separate plugin in `plugins/browser/browser_use/` |

If a user's workflow uses `browser_exec` with a local `cdp_url`, disabling the browser-use **plugin** breaks nothing. Check `.env` for `BROWSER_USE_API_KEY` before claiming the cloud backend is in play.

## Desktop native notifications (shipped v2026.6.19)

- **Where configured**: Settings → Notifications (bell icon) in the desktop app. **Device-local** — renderer localStorage, NOT config.yaml. Keys: `hermes:native-notifications` (master `enabled` + per-kind map), `hermes.desktop.completionSoundVariantId` (completion sound, variants 1–14).
- **Kinds**: `approval`, `input`, `turnDone`, `turnError`, `backgroundDone`, `credits`, `plugin`.
- **Firing rules**: completion kinds (`turnDone`/`turnError`/`backgroundDone`) fire only when the window is backgrounded or unfocused (alt-tab counts) and only for the active session. Attention kinds (`approval`, `input`) also fire for off-screen background sessions. 1s per-(kind, session) throttle; 4s quiet window after gateway connect (replayed state doesn't notify).
- **Sound**: the turn-end completion sound picker lives in Settings → Notifications (moved from Appearance). No per-app volume control yet (open feature request).
- **macOS side**: if test notifications don't appear, check Réglages Système → Notifications for Hermes; TCC grants are keyed to the app's code-signing identity.
- Related CLI-side config (different surface!): `display.bell_on_complete` in config.yaml governs the terminal bell, not desktop notifications.

## Debugging entry points

- Native notif prefs engine: `apps/desktop/src/store/native-notifications.ts`
- Sound store: `apps/desktop/src/store/completion-sound.ts`
- Settings UI: `apps/desktop/src/app/settings/notifications-settings.tsx`
- Dispatch sites: `apps/desktop/src/hooks/use-message-stream.ts`

## Pitfalls

- Don't answer "the plugin list shows it enabled therefore it's active" — see golden rule.
- Desktop notification prefs are per-device localStorage; changing them via CLI/config.yaml is impossible, and wiping app data resets them.
- `hermes plugins list` truncates table cells; grep the name column, not descriptions.