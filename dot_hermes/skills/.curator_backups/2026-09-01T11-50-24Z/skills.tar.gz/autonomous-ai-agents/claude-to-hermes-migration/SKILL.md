---
name: claude-to-hermes-migration
description: "Use when migrating a Claude Desktop workspace into Hermes."
version: 1.0.0
---

# Claude Desktop → Hermes Migration

How to replace an ex-Claude Desktop setup with Hermes equivalents, validated on a real
migration (Finances + prospection + scheduled skills, 2026-08).

## Concept mapping

| Claude Desktop | Hermes |
|---|---|
| Project (folder + CLAUDE.md) | desktop Project (`project_create` with `path`) + `.hermes.md` at folder root |
| CLAUDE.md project rules | `.hermes.md` (auto-injected when working in that subtree) |
| Artifacts (.html one-offs) | just archive; no active import needed |
| Scheduled skills / automations | cron jobs or Hermes skills — only if user wants them rebuilt |
| Memory/context files | Hermes memory tool for durable facts |

## Workflow

1. **Inventory first**: walk the source folder (e.g.
   `~/Library/Mobile Documents/com~apple~CloudDocs/Documents/Claude`), print tree with sizes,
   then read the key content files (journal/notes .md, xlsx sheets via openpyxl) BEFORE proposing anything.
2. **Propose an import plan grouped by value** (active import / archive / skip), let the user veto per group.
3. **Copy, don't move** the chosen files into the destination project folder; keep xlsx as-is.
4. **Create the desktop Project** anchored at the new folder, then write a `.hermes.md`
   containing: file inventory, non-negotiable rules extracted from the old CLAUDE.md/journal,
   current state snapshot, next actions, conventions (update registry AND journal after every change).
5. Save durable facts (location, rules, current totals) to memory too.

## Pitfalls

- **Ask for the folder convention BEFORE creating any Project** — user may want a parent folder
  (`Documents/Hermes/<Project>/`) rather than per-project folders cluttering Documents.
- **No project delete/rename tool exists.** A Project created at a wrong path cannot be removed
  programmatically — it lingers as a duplicate in the sidebar; only the user can delete it in the app UI
  (right-click). Recreating at the right path + `project_switch` works but leaves the ghost.
- Moving a folder after creating the Project leaves the Project pointing at the old path;
  recreate + switch.
- iCloud paths contain spaces and `~`: always quote them in shell commands.

## Reading xlsx without Excel

```bash
python3 - <<'EOF'
import openpyxl
wb = openpyxl.load_workbook(path)          # no data_only → formulas preserved for editing
for ws in wb.worksheets:
    for row in ws.iter_rows(values_only=True): ...
EOF
```
Load workbooks WITHOUT `data_only=True` when you plan to edit, so formulas survive.
Note: pip is PEP 668 locked on this Mac but `python3 -m pip install --user openpyxl` works;
user-site packages are NOT on the execute_code sandbox's sys.path — run xlsx scripts through
`terminal()` instead of `execute_code`.
