---
name: web-source-verification
description: Use when finding/verifying web links without a search tool.
---

# Web source discovery & verification without a search tool

When the user asks for links, podcast appearances, articles, etc., never output URLs from memory — verify them first. If a `web_search`-style tool exists, use it; otherwise these curl-based patterns work from `execute_code`/terminal.

## Search via DuckDuckGo HTML endpoint

```bash
curl -sL -A 'Mozilla/5.0' 'https://html.duckduckgo.com/html/?q=QUERY'
```

- Must send a browser User-Agent or results come back empty.
- Extract real destinations by decoding the `uddg=` redirect param:
  ```python
  import re, urllib.parse
  links = set(re.findall(r'uddg=([^&"]+)', html))
  print([urllib.parse.unquote(l) for l in links])
  ```
- Dedupe with a set — each result appears ~3x in the raw HTML.

## Verify a YouTube link without scraping

```
curl -sL 'https://www.youtube.com/oembed?url=<VIDEO_URL>&format=json'
```
Returns canonical `title` and `author_name` (channel). Cheap proof the video exists and what it actually is before sharing.

## Pitfalls
- Don't grep for CSS classes like `result__a` — use the `html.duckduckgo.com/html` host with uddg extraction instead.
- Only present links actually fetched/verified this session; tell the user explicitly which are verified vs. suggested follow-up searches.
- URL-encode queries (`urllib.parse.quote`) before embedding in the search URL.

## Known sources (session-verified)
- Teknium (Nous Research): no own podcast; guest episodes listed at teknium.io; ThursdAI guest page thursdai.news/guests/teknium1.