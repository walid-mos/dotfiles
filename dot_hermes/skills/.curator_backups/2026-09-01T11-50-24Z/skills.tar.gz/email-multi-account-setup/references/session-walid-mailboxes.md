# Session detail: Walid's 4-mailbox setup (2026-08-24)

Concrete state and provider-specific findings from the session that produced
this skill. Kept out of SKILL.md so it stays class-level.

## Accounts configured

| Account | himalaya name | Auth | Status |
|---|---|---|---|
| pro.walid.mostefaoui@gmail.com | `gmail` | Keychain app password (`hermes-himalaya-gmail`) | ✅ working |
| walidmostefaoui@nextnode.fr (Zoho EU) | `zoho` | Keychain app password (`hermes-himalaya-zoho`) | ✅ imap: OK |
| w.mostefaoui@outlook.fr | `outlook1` | basic auth | ❌ "Basic authentication is disabled" |

Config lives at `~/.config/himalaya/config.toml` (v2 syntax). Secrets in macOS
login keychain, service names prefixed `hermes-himalaya-*`.

## Gmail app-password gotcha

`myaccount.google.com/apppasswords` shows "The setting you are looking for is
not available for your account" until 2-Step Verification is enabled. Order:
enable 2FA → then app passwords page appears.

## Zoho app-password location

NOT in Zoho Mail settings ("Connecteur" is something else). It's in the
account-level console: accounts.zoho.com → Security → App Passwords →
Generate New Password. Shown once only.

## Microsoft personal-account dead ends (all tested this session)

1. Thunderbird client id `08162f7c-0fd2-4200-a84a-f25a4db0b584`, device code:
   - `/consumers` endpoint → AADSTS9002332 "configured for use by Azure Active
     Directory users only".
   - `/common` endpoint → device code issued fine (login.microsoft.com/device),
     but token POST returns HTTP 400 invalid_grant AADSTS7000014.
2. Azure CLI client id `d3590ed6-52b3-4102-aeff-aad2292ab01c`, device code via
   `/consumers`: code issued, but browser consent page rejects with "users are
   not permitted to consent to first party applications" (invalid_request).
3. Entra ID portal: personal @outlook.fr accounts cannot sign in at all — error
   "user does not exist in tenant Microsoft Services". App registration is a
   work/school-only path.

## Where the real solution lives

himalaya v2 moved OAuth out of the CLI (issue #618): the wizard only wires a
token-broker command. Brokers: **ortie** (same author, pimalaya), pizauth,
oama. Ortie README documents the public Thunderbird Outlook IMAP/SMTP app:

```toml
client-id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"
endpoints.redirection = "https://localhost"
endpoints.authorization = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
endpoints.token = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
```

Ortie v2.2.0 prebuilt arm64-darwin tarball installs cleanly to /usr/local/bin.
Not yet driven end-to-end; that's the next step when resuming this task.

## Tooling notes

- himalaya 2.1.0 via brew; JSON flag is global `--json`; folder flag `-m`.
- Wizard needs a TTY: tmux + staged `send-keys` works; plain pty pipes don't.
- `strings` on the stripped brew binary reveals no embedded client ids — read
  GitHub source (`src/wizard/*.rs`) and ortie README instead.
