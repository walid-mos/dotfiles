---
name: email-multi-account-setup
description: "Wire Gmail/Zoho/Outlook into himalaya v2 CLI mail."
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [Email, IMAP, SMTP, OAuth, Setup]
---

# Email Multi-Account Setup (CLI / IMAP)

Class-level procedure for wiring multiple real-world mailboxes into a terminal
client (himalaya), with per-provider quirks learned in production.

> The bundled `email/himalaya` skill documents himalaya generally, but its TOML
> examples are **v1.x syntax** — broken on himalaya 2.x. Use the config shape
> below instead.

## ⚠️ himalaya v2.x config syntax (validated on 2.1.0)

v1 syntax (`backend.type = "imap"`, `folder.aliases.*`) parses fine on v2 but
registers NO backend: `himalaya account list` shows an empty BACKENDS column
and every command fails with `No backend matching 'auto' is configured`.

Working v2 shape:

```toml
[accounts.<name>]
email = "you@example.com"
display-name = "You"

imap.server = "imaps://<host>:993"
imap.sasl.plain.username = "you@example.com"
imap.sasl.plain.password.command = ["security", "find-generic-password", "-a", "you@example.com", "-s", "<service>", "-w"]

smtp.server = "smtps://<host>:465"
smtp.sasl.plain.password.command = ["security", "find-generic-password", "-a", "you@example.com", "-s", "<service>", "-w"]

mailbox.alias.inbox = "INBOX"
mailbox.alias.sent = "[Gmail]/Sent Mail"
```

Verify each account: `himalaya account check --account <name> --backend imap`
(must print `imap: OK`). Also note: JSON flag is now global `--json`; folder
flag is `-m/--mailbox`; the wizard needs a real TTY (tmux, not plain pty pipe).

## Provider cheat-sheet

| Provider | IMAP | SMTP | Auth that works |
|---|---|---|---|
| Gmail | imap.gmail.com:993 | smtp.gmail.com:465 | App password (requires 2FA first; app-passwords page is hidden until 2FA is on) |
| Zoho EU | imap.zoho.eu:993 | smtp.zoho.eu:465 | App password from **accounts.zoho.com → Security → App Passwords** (NOT inside Zoho Mail settings) |
| Outlook personal (@outlook.fr/.com/hotmail) | outlook.office365.com:993 | smtp.office365.com:587 (STARTTLS) | ❌ NOTHING simple works — see below |

## The Microsoft personal-account OAuth wall (2026 state)

Since ~Sept 2024 Microsoft disabled basic auth AND app passwords for IMAP on
personal accounts ("NO Basic authentication is disabled."). Dead ends verified:

- Thunderbird client-id device-code flow → AADSTS9002332 "Azure AD users only"
  via `/consumers`; via `/common` it issues codes but token exchange 400s.
- First-party MS client ids (Azure CLI d3590ed6…) → consent blocked:
  "users are not permitted to consent to first party applications".
- Entra ID app registration → requires a work/school account; personal
  @outlook.fr accounts cannot sign in to Entra at all.
- himalaya's own wizard does NOT do OAuth itself (v2 delegates to brokers:
  Ortie/pizauth/oama); its Keychain strategy stores only a secret reference.

Remaining viable paths (in preference order):
1. **Ortie broker** (`github.com/pimalaya/ortie`, ships prebuilt arm64-darwin)
   with the public Thunderbird Outlook client-id
   `9e5f94bc-e8a4-4e73-b8be-63364c29d753` + redirect `https://localhost`,
   endpoints `/common/oauth2/v2.0/*`, scopes IMAP.AccessAsUser.All,
   SMTP.Send, offline_access. Then point himalaya at
   `imap.sasl.plain.password.command = ["ortie", "token", "show"]`.
   (Untested end-to-end as of this skill's writing — verify before trusting.)
2. **Forwarding**: enable auto-forward from the Outlook mailbox to an
   account that already works (e.g. Gmail); read everything from there.

## Debugging patterns

- Auth failure vs config failure: run `himalaya account check --backend imap`
  per account before blaming credentials.
- `strings` on the brew binary won't reveal embedded client ids (stripped);
  read the GitHub source tree (`src/wizard/*.rs`) and README of ortie instead.
- Interactive TUI wizards under Hermes: use tmux sessions with staged
  `send-keys` + `capture-pane`, never bare pty pipes.
